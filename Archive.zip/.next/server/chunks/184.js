"use strict";
exports.id = 184;
exports.ids = [184];
exports.modules = {

/***/ 184:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ AppWrapper),
/* harmony export */   "b": () => (/* binding */ useAppContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const AppContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({});
function AppWrapper({ children  }) {
    const [enhanceTextInput, setEnhanceTextInput] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [emailTextInput, setEmailTextInput] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [emailRecipient, setEmailRecipient] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [emailSender, setEmailSender] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [summarizeTextInput, setSummarizeTextInput] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [enhanceResult, setEnhanceResult] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [emailResult, setEmailResult] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [summarizeResult, setSummarizeResult] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [enhanceLoading, setEnhanceLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("notStarted");
    const [emailLoading, setEmailLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("notStarted");
    const [summarizeLoading, setSummarizeLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("notStarted");
    async function onSubmit(job) {
        try {
            const textInput = getTextInput(job);
            const recipient = getRecipient(job);
            const sender = getSender(job);
            const setLoading = getSetLoading(job);
            if (enhanceTextInput !== "") {
                setLoading("IsLoading");
            }
            const response = await fetch("/api/hello", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    text: textInput,
                    type: job,
                    recipient,
                    sender
                })
            });
            const data = await response.json();
            if (response.status !== 200) {
                throw data.error || new Error(`Request failed with status ${response.status}`);
            }
            setResult(job, data.result);
            setLoading("FinishedLoading");
        } catch (error) {
            console.error(error);
            alert(error.message);
        }
    }
    function getTextInput(job) {
        switch(job){
            case "enhance":
                return enhanceTextInput;
            case "email":
                return emailTextInput;
            case "summarize":
                return summarizeTextInput;
            default:
                return "";
        }
    }
    function getRecipient(job) {
        return job === "email" ? emailRecipient : "";
    }
    function getSender(job) {
        return job === "email" ? emailSender : "";
    }
    function getSetLoading(job) {
        switch(job){
            case "enhance":
                return setEnhanceLoading;
            case "email":
                return setEmailLoading;
            case "summarize":
                return setSummarizeLoading;
            default:
                return ()=>{};
        }
    }
    function setResult(job, result) {
        switch(job){
            case "enhance":
                setEnhanceResult(result);
                break;
            case "email":
                setEmailResult(result);
                break;
            case "summarize":
                setSummarizeResult(result);
                break;
            default:
                break;
        }
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AppContext.Provider, {
        value: {
            enhanceTextInput,
            setEnhanceTextInput,
            enhanceResult,
            setEnhanceResult,
            enhanceLoading,
            setEnhanceLoading,
            emailTextInput,
            setEmailTextInput,
            emailResult,
            setEmailResult,
            emailLoading,
            setEmailLoading,
            summarizeTextInput,
            setSummarizeTextInput,
            summarizeResult,
            setSummarizeResult,
            summarizeLoading,
            setSummarizeLoading,
            emailRecipient,
            setEmailRecipient,
            emailSender,
            setEmailSender,
            onSubmit
        },
        children: children
    });
}
function useAppContext() {
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(AppContext);
}


/***/ })

};
;