"use strict";
(() => {
var exports = {};
exports.id = 453;
exports.ids = [453];
exports.modules = {

/***/ 463:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ hello)
});

;// CONCATENATED MODULE: external "openai"
const external_openai_namespaceObject = require("openai");
;// CONCATENATED MODULE: ./src/pages/api/hello.tsx

const configuration = new external_openai_namespaceObject.Configuration({
    apiKey: process.env.OPENAI_API_KEY
});
const openai = new external_openai_namespaceObject.OpenAIApi(configuration);
/* harmony default export */ async function hello(req, res) {
    if (!configuration.apiKey) {
        res.status(500).json({
            error: {
                message: "OpenAI API key not configured, please follow instructions in README.md"
            }
        });
        return;
    }
    const text = req.body.text || "";
    const type = req.body.type || "";
    const recipient = req.body.recipient || "";
    const sender = req.body.sender || "";
    if (text.trim().length === 0) {
        res.status(400).json({
            error: {
                message: "Please enter a valid text"
            }
        });
        return;
    }
    try {
        const completion = await openai.createCompletion({
            model: "text-davinci-003",
            prompt: generatePrompt(text, type, recipient, sender),
            temperature: 0.6,
            max_tokens: 2000
        });
        res.status(200).json({
            result: completion.data.choices[0].text
        });
    } catch (error) {
        if (error.response) {
            console.error(error.response.status, error.response.data);
            res.status(error.response.status).json(error.response.data);
        } else {
            console.error(`Error with OpenAI API request: ${error.message}`);
            res.status(500).json({
                error: {
                    message: "An error occurred during your request."
                }
            });
        }
    }
}
function generatePrompt(text, type, recipient, sender) {
    switch(type){
        case "enhance":
            return `Please review and revise 'My Text' for professionalism and grammatical accuracy. Your task is to improve the text to ensure it meets the highest standards of written communication. My Text: "${text.replace(/[\n\r]/g, " ")}"`;
        case "email":
            return `Compose an email from 'Sender' to 'Recipient' regarding the information outlined in 'Notes', and create a suitable email subject line. Please ensure that the email is written professionally and is grammatically correct. The names and text are as follows: Recipient: "${recipient}". Sender: "${sender}". Notes: "${text}".`;
        case "summarize":
            return `Please summarize the key points and essential details covered in 'My Text'. Your summary should include relevant information on the topic, key arguments or ideas presented, and any notable insights or conclusions. Please ensure that your summary is clear, concise, and accurately captures the main points of the text. Here is the text for your reference: "${text}"`;
        default:
            return `Please repeat after me: Excuse me, ${type} is not a Job I offer.`;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(463));
module.exports = __webpack_exports__;

})();